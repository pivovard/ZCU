% predict y values from X and theta.
% X is the matrix where each row is one training example
% You should return a column vector of y
function [y] = predict(X, theta)
% TODO predict y value
  y = X * theta;
end

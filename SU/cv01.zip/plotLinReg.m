clc; clear all; close all;

x = [1 1 2 3];
y = [2 3 1 4];
X = [ones(length(x), 1) x']
plot(x, y, 'rx', 'MarkerSize', 10);
axis([0 10 0 10]);

hold on;

theta = (X' * X) \ X' * y'
xx = linspace(0, 10, 100);
XX = [ones(length(xx), 1) xx'];
plot(xx, XX * theta);


X = [ones(length(x), 1) x' x' .^ 2]
xtx = X' * X;
xtxn = xtx ^ -1;


theta = (X' * X) \ X' * y'
xx = linspace(0, 10, 100);
XX = [ones(length(xx), 1) xx' xx' .^ 2];
plot(xx, XX * theta, 'color', 'r');

legend(['data'; 'lineární regrese'; 'kvadratická regrese']);

% This function should create one/hot vektor for each string in X matrix
% X is the matrix where each row is a single string
% X_trans is the matrix where each row is one-hot vector for single input string 
function [X_trans] = dictionaryFT_transform (X, model)

end

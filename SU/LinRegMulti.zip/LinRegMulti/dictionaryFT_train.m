% Trains dictionarz feature transformer
% it has to remember the indices of strings in vocabulary
% So the transformer can create a vector with single 1 on corresponding index
% X is the matrix where each row is a single string
function [model] = dictionaryFT_train (X)

end

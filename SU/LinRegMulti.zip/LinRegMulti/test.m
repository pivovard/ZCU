A = ones(5)

B = eye(5)

A ./ B
#pragma once

void shrink(char *input_file, char *output_file, int thread_count, bool ordered);
#pragma once

void check(char *input_file, int thread_count);
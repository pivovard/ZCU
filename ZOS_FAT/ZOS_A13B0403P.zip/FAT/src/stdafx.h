// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include<iostream>
#include<fstream>
#include <tchar.h>
//#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <thread>
#include <mutex>
#include <time.h>

#include "struct.h"
#include "reader.h"
#include "shrink.h"
#include "check.h"

using namespace std;

// TODO: reference additional headers your program requires here

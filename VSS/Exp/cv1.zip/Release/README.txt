Run by:

exp3.exe n lambda1 lambda2 p


Params:

int n			- number of generated numbers
double lambda1	- param od distribution 1
double lambda2	- param od distribution 2
double p <0,1>	- probabilty of distribution 1
<?php

function read($file = "zvirata.txt")
{
    
    return $file;
}



?>
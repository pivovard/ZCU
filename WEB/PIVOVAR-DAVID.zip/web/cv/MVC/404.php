<?php

echo "<h1>404 Stranka nenalezena!</h1>";

?>
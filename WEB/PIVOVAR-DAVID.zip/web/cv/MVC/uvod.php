
<?php

global $subpage;

echo "Uvod".$subpage;
    
?>
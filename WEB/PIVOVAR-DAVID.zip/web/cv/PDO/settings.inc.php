<?php

    define("DB_SERVER","students.kiv.zcu.cz");
    define("DB_DATABASE_NAME","db1_vyuka");
    define("DB_USER_LOGIN","db1_vyuka");
    define("DB_USER_PASSWORD","db1_vyuka");

    $db_server = "students.kiv.zcu.cz";
    $db_port = "3306";
    $db_user = "db1_vyuka";
    $db_pass = "db1_vyuka";
?>
<header class="jumbotron">
    <h1>Company</h1>
    <p class="header-odsazeni" style="color:grey;">...conference system</p> 
</header>

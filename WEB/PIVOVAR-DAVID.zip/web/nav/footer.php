<footer class="container-fluid text-right">
    <p>Created by David Pivovar, 2016</p>
</footer>
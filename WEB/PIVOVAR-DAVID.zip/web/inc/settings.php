<?php

    define("DB_SERVER","localhost");
    define("DB_DATABASE_NAME","web_sp");
    define("DB_USER_LOGIN","web_sp");
    define("DB_USER_PASSWORD","web_sp");

    $db_server = "students.kiv.zcu.cz";
    $db_port = "3306";
    $db_user = "db1_vyuka";
    $db_pass = "db1_vyuka";
    $db_name = "db1_vyuka";


?>
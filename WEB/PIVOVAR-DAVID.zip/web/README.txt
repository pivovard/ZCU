
KIV/WEB
Webove stranky konferencniho systemu

David Pivovar
A13B0403P
pivovar@students.zcu.cz

https://github.com/pivovard/web


index.php - vstupni bod webove aplikace, pouziti sablony Twig

index.old.php - puvodni vstupni bod webove aplikace, include obsahu stranek

.htaccess - presmerovani URL adres jednotlivych stranek na index.php

\cont - obsah stranek

\nav - navigation bar, postrani navigation bar, hlavicka paticka

\inc - soubory aplikace (prace s databazi, s clanky, priasovani uzivatelu)

\css - css soubory

\sablony - sablona Twigu pouzita v aplikaci

\twig-master - knihovny Twigu

\pdf - nahrane .pdf a .txt dokumenty clanku

\sql - scrity pro vytvoreni uzivatele v databazi, tabulek a jejich naplneni testovacimi daty (export z MySQLWorkbanch a phpMyAdmin)

\doc - dokumentace